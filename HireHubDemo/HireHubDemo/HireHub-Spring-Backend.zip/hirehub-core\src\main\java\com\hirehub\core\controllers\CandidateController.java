package com.hirehub.core.controllers;

import com.hirehub.core.dtos.JobDTO;
import com.hirehub.core.entities.*;
import com.hirehub.core.repositories.*;
import com.hirehub.core.security.JwtService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/candidate")
@CrossOrigin
@PreAuthorize("hasRole('ROLE_CANDIDATE')")
public class CandidateController {

    @Autowired
    private JobRepository jobRepository;

    @Autowired
    private JobApplicationRepository applicationRepository;

    @Autowired
    private CandidateRepository candidateRepository;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private UserRepository userRepository;

    private Candidate getCandidate(HttpServletRequest request) {
        String token = request.getHeader("Authorization").substring(7);
        String email = jwtService.extractUsername(token);
        User user = userRepository.findByEmail(email).orElseThrow();
        return candidateRepository.findByUserId(user.getId()).orElseThrow();
    }

    @GetMapping("/jobs")
    public List<Job> getAllJobs() {
        return jobRepository.findByStatus(Job.Status.OPEN);
    }

    @PostMapping("/apply/{jobId}")
    public ResponseEntity<?> applyJob(@PathVariable Long jobId, HttpServletRequest request) {
        Candidate candidate = getCandidate(request);
        Job job = jobRepository.findById(jobId).orElseThrow();

        if (applicationRepository.findByJobIdAndCandidateId(jobId, candidate.getId()).isPresent()) {
            return ResponseEntity.badRequest().body("Already Applied");
        }

        JobApplication application = new JobApplication();
        application.setJob(job);
        application.setCandidate(candidate);
        application.setStatus(JobApplication.Status.APPLIED);
        applicationRepository.save(application);
        return ResponseEntity.ok("Applied Successfully");
    }

    @GetMapping("/applications")
    public List<JobApplication> myApplications(HttpServletRequest request) {
        Candidate candidate = getCandidate(request);
        return applicationRepository.findByCandidateId(candidate.getId());
    }
}
