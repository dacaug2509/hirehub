package com.hirehub.core.controllers;

import com.hirehub.core.dtos.AuthRequest;
import com.hirehub.core.dtos.AuthResponse;
import com.hirehub.core.dtos.RegisterRequest;
import com.hirehub.core.entities.Candidate;
import com.hirehub.core.entities.Company;
import com.hirehub.core.entities.User;
import com.hirehub.core.repositories.CandidateRepository;
import com.hirehub.core.repositories.CompanyRepository;
import com.hirehub.core.repositories.UserRepository;
import com.hirehub.core.security.JwtService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
@CrossOrigin // Allow all for demo
public class AuthController {

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private CompanyRepository companyRepository;

    @Autowired
    private CandidateRepository candidateRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody RegisterRequest request) {
        if (userRepository.existsByEmail(request.getEmail())) {
            return ResponseEntity.badRequest().body("Email already exists");
        }

        User user = new User();
        user.setEmail(request.getEmail());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setRole(request.getRole());
        user.setActive(true); // Default true

        // Role specific logic
        if (request.getRole() == User.Role.COMPANY) {
            // Check if name provided
            if (request.getName() == null)
                return ResponseEntity.badRequest().body("Company Name is required");
            // Save User
            User savedUser = userRepository.save(user);
            // Save Company
            Company company = new Company();
            company.setUser(savedUser);
            company.setName(request.getName());
            company.setStatus(Company.Status.PENDING); // Pending approval
            companyRepository.save(company);
            return ResponseEntity.ok("Company registered successfully. Waiting for Admin approval.");
        } else if (request.getRole() == User.Role.CANDIDATE) {
            if (request.getName() == null)
                return ResponseEntity.badRequest().body("Candidate Name is required");
            User savedUser = userRepository.save(user);
            Candidate candidate = new Candidate();
            candidate.setUser(savedUser);
            candidate.setName(request.getName());
            candidate.setSkills(request.getSkills());
            candidate.setExperience(request.getExperience());
            candidate.setResumeUrl(request.getResumeUrl());
            candidate.setProfileUrl(request.getProfileUrl());
            candidateRepository.save(candidate);
            return ResponseEntity.ok("Candidate registered successfully");
        } else if (request.getRole() == User.Role.ADMIN) {
            // Only manual seed allowed usually, but for demo:
            userRepository.save(user);
            return ResponseEntity.ok("Admin registered");
        }

        return ResponseEntity.badRequest().body("Invalid Role");
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody AuthRequest authRequest) {
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(authRequest.getEmail(), authRequest.getPassword()));

        if (authentication.isAuthenticated()) {
            User user = userRepository.findByEmail(authRequest.getEmail()).orElseThrow();

            // Check Company Approval
            if (user.getRole() == User.Role.COMPANY) {
                Company company = companyRepository.findByUserId(user.getId()).orElse(null);
                if (company != null && company.getStatus() == Company.Status.PENDING) {
                    return ResponseEntity.status(403).body("Company not approved yet");
                }
            }

            String token = jwtService.generateToken(authRequest.getEmail(), user.getRole().name());
            return ResponseEntity.ok(new AuthResponse(token, user.getRole(), user.getId()));
        } else {
            throw new UsernameNotFoundException("Invalid user request !");
        }
    }
}
