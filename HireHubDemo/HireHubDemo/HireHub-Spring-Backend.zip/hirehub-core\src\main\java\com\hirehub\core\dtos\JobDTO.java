package com.hirehub.core.dtos;

import lombok.Data;

@Data
public class JobDTO {
    private String title;
    private String description;
    private String requiredSkills;
}
