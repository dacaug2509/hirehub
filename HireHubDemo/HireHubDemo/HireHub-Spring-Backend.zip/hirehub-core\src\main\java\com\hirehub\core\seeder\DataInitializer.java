package com.hirehub.core.seeder;

import com.hirehub.core.entities.User;
import com.hirehub.core.repositories.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public DataInitializer(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) throws Exception {
        // Create Admin if not exists
        if (!userRepository.existsByEmail("admin@hirehub.com")) {
            User admin = new User();
            admin.setEmail("admin@hirehub.com");
            admin.setPassword(passwordEncoder.encode("admin123"));
            admin.setRole(User.Role.ADMIN);
            admin.setActive(true);
            userRepository.save(admin);
            System.out.println("✅ DEFAULT ADMIN USER CREATED: admin@hirehub.com / admin123");
        }

        // Optional: Create a demo company and candidate for testing
        if (!userRepository.existsByEmail("company@hirehub.com")) {
            User emp = new User();
            emp.setEmail("company@hirehub.com");
            emp.setPassword(passwordEncoder.encode("company123"));
            emp.setRole(User.Role.COMPANY);
            emp.setActive(true);
            userRepository.save(emp);
            System.out.println("✅ DEFAULT COMPANY USER CREATED: company@hirehub.com / company123");
        }
    }
}
