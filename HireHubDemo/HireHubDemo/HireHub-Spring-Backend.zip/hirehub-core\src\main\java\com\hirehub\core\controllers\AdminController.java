package com.hirehub.core.controllers;

import com.hirehub.core.entities.Company;
import com.hirehub.core.entities.User;
import com.hirehub.core.repositories.CompanyRepository;
import com.hirehub.core.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admin")
@CrossOrigin
@PreAuthorize("hasRole('ROLE_ADMIN')")
public class AdminController {

    @Autowired
    private CompanyRepository companyRepository;

    @Autowired
    private UserRepository userRepository;

    @GetMapping("/companies/pending")
    public List<Company> getPendingCompanies() {
        return companyRepository.findByStatus(Company.Status.PENDING);
    }

    @PutMapping("/company/{id}/approve")
    public ResponseEntity<?> approveCompany(@PathVariable Long id) {
        Company company = companyRepository.findById(id).orElseThrow();
        company.setStatus(Company.Status.APPROVED);
        companyRepository.save(company);
        return ResponseEntity.ok("Company Approved");
    }

    @DeleteMapping("/company/{id}")
    public ResponseEntity<?> deleteCompany(@PathVariable Long id) {
        Company company = companyRepository.findById(id).orElseThrow();
        userRepository.deleteById(company.getUser().getId()); // Start Cascade
        return ResponseEntity.ok("Company Deleted");
    }

    @GetMapping("/users")
    public List<User> getUsersByRole(@RequestParam User.Role role) {
        // Simple findAll and filter for demo, implementing custom repository method is
        // better but this works for small data
        // Actually I can't filter by Enum easily with standard JPA method unless I add
        // it to UserRepository.
        // I added JpaRepository<User, Long>, but not findByRole. I'll fetch all or use
        // streams.
        return userRepository.findAll().stream().filter(u -> u.getRole() == role).toList();
    }
}
