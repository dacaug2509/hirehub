package com.hirehub.core.controllers;

import com.hirehub.core.dtos.JobDTO;
import com.hirehub.core.entities.*;
import com.hirehub.core.repositories.*;
import com.hirehub.core.security.JwtService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/company")
@CrossOrigin
@PreAuthorize("hasRole('ROLE_COMPANY')")
public class CompanyController {

    @Autowired
    private JobRepository jobRepository;

    @Autowired
    private CompanyRepository companyRepository;

    @Autowired
    private JobApplicationRepository applicationRepository;

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private UserRepository userRepository;

    private Company getCompany(HttpServletRequest request) {
        String token = request.getHeader("Authorization").substring(7);
        String email = jwtService.extractUsername(token);
        User user = userRepository.findByEmail(email).orElseThrow();
        return companyRepository.findByUserId(user.getId()).orElseThrow();
    }

    @PostMapping("/jobs")
    public ResponseEntity<?> postJob(@RequestBody JobDTO jobDTO, HttpServletRequest request) {
        Company company = getCompany(request);
        Job job = new Job();
        job.setCompany(company);
        job.setTitle(jobDTO.getTitle());
        job.setDescription(jobDTO.getDescription());
        job.setRequiredSkills(jobDTO.getRequiredSkills());
        job.setStatus(Job.Status.OPEN);
        jobRepository.save(job);
        return ResponseEntity.ok("Job Posted");
    }

    @GetMapping("/jobs")
    public List<Job> getMyJobs(HttpServletRequest request) {
        Company company = getCompany(request);
        return jobRepository.findByCompanyId(company.getId());
    }

    @DeleteMapping("/jobs/{id}")
    public ResponseEntity<?> deleteJob(@PathVariable Long id) {
        // Validation ownership omitted for brevity
        jobRepository.deleteById(id);
        return ResponseEntity.ok("Job Deleted");
    }

    @GetMapping("/jobs/{id}/applicants")
    public List<JobApplication> getJobApplicants(@PathVariable Long id) {
        return applicationRepository.findByJobId(id);
    }

    @PutMapping("/application/{id}/status")
    public ResponseEntity<?> updateStatus(@PathVariable Long id, @RequestParam JobApplication.Status status) {
        JobApplication application = applicationRepository.findById(id).orElseThrow();
        application.setStatus(status);
        applicationRepository.save(application);
        return ResponseEntity.ok("Status Updated");
    }

    @GetMapping("/employees")
    public List<Employee> getEmployees(HttpServletRequest request) {
        Company company = getCompany(request);
        return employeeRepository.findByCompanyId(company.getId());
    }
}
