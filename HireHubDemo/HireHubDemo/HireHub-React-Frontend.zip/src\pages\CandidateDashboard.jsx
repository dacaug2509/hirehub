import { useEffect, useState } from 'react';
import { Routes, Route, Link, useNavigate, useLocation } from 'react-router-dom';
import api from '../api/axios';

const CandidateDashboard = () => {
    const location = useLocation();

    return (
        <div className="min-h-screen flex bg-[#0f1016]">
            <aside className="w-72 glass border-r border-white/10 flex flex-col fixed h-full z-20">
                <div className="p-8">
                    <h2 className="text-3xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-400">HireHub</h2>
                    <div className="text-xs text-blue-300/50 tracking-widest mt-1 uppercase">Candidate Portal</div>
                </div>
                <nav className="flex-1 space-y-2 px-4">
                    <NavItem to="/candidate" label="Find Jobs" icon="🔍" active={location.pathname === '/candidate'} />
                    <NavItem to="/candidate/applications" label="My Applications" icon="📁" active={location.pathname === '/candidate/applications'} />
                </nav>
                <div className="p-6 border-t border-white/5 bg-black/20">
                    <div className="text-xs text-gray-500">Logged in as Candidate</div>
                </div>
            </aside>
            <main className="flex-1 ml-72 p-10 overflow-y-auto">
                <Routes>
                    <Route path="/" element={<FindJobs />} />
                    <Route path="/applications" element={<MyApplications />} />
                </Routes>
            </main>
        </div>
    );
};

const NavItem = ({ to, label, icon, active }) => (
    <Link to={to} className={`flex items-center gap-3 px-5 py-4 rounded-xl transition-all duration-300 group ${active ? 'bg-cyan-600/20 text-cyan-300 border border-cyan-500/20 shadow-lg shadow-cyan-500/10' : 'text-gray-400 hover:bg-white/5 hover:text-white'}`}>
        <span className="text-xl group-hover:scale-110 transition-transform">{icon}</span>
        <span className="font-medium">{label}</span>
    </Link>
);

const FindJobs = () => {
    const [jobs, setJobs] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');

    useEffect(() => {
        api.get('/candidate/jobs').then(res => setJobs(res.data));
    }, []);

    const apply = async (id) => {
        try {
            await api.post(`/candidate/apply/${id}`);
            alert('Application Submitted Successfully! 🚀');
        } catch (err) {
            alert(err.response?.data || 'Failed to apply');
        }
    };

    return (
        <div className="animate-fade-in">
            <div className="flex justify-between items-center mb-10">
                <div>
                    <h2 className="text-4xl font-bold mb-2">Explore Opportunities</h2>
                    <p className="text-gray-400">Find your next dream job at top companies</p>
                </div>
                <div className="relative">
                    <input
                        placeholder="Search by title or keyword..."
                        className="input-field w-80 pl-10"
                        onChange={e => setSearchTerm(e.target.value)}
                    />
                    <span className="absolute left-3 top-3.5 text-gray-400">🔍</span>
                </div>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-1 xl:grid-cols-2 gap-8">
                {jobs.filter(j => j.title.toLowerCase().includes(searchTerm.toLowerCase())).map(job => (
                    <div key={job.id} className="glass p-8 rounded-3xl group hover:border-cyan-500/30 transition-all shadow-lg hover:shadow-cyan-500/10 relative overflow-hidden">
                        <div className="absolute top-0 right-0 w-32 h-32 bg-cyan-500/5 rounded-full blur-2xl group-hover:bg-cyan-500/10 transition-colors"></div>

                        <div className="flex justify-between items-start mb-4">
                            <div>
                                <h3 className="text-2xl font-bold text-white group-hover:text-cyan-300 transition-colors">{job.title}</h3>
                                <div className="text-xs font-bold uppercase tracking-wider text-gray-500 mt-1">Full Time • Remote Friendly</div>
                            </div>
                            <button onClick={() => apply(job.id)} className="btn-primary py-2 px-6 text-sm bg-gradient-to-r from-cyan-500 to-blue-500 hover:scale-105 shadow-cyan-500/20">
                                Apply Now
                            </button>
                        </div>

                        <p className="text-gray-400 mb-6 leading-relaxed">{job.description}</p>

                        <div className="flex flex-wrap gap-2">
                            {job.requiredSkills.split(',').map(skill => (
                                <span key={skill} className="text-xs font-bold text-cyan-200 bg-cyan-500/10 px-3 py-1.5 rounded-full border border-cyan-500/20">
                                    {skill.trim()}
                                </span>
                            ))}
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

const MyApplications = () => {
    const [apps, setApps] = useState([]);
    useEffect(() => {
        api.get('/candidate/applications').then(res => setApps(res.data));
    }, []);

    return (
        <div className="animate-fade-in">
            <h2 className="text-4xl font-bold mb-8">Application Status</h2>
            <div className="grid gap-4">
                {apps.map(app => (
                    <div key={app.id} className="glass p-6 rounded-2xl flex justify-between items-center border-l-4 border-l-transparent hover:border-l-cyan-400 transition-all">
                        <div>
                            <h3 className="font-bold text-xl mb-1">{app.job?.title}</h3>
                            <p className="text-sm text-gray-400">Applied on: {new Date(app.appliedAt).toLocaleDateString()}</p>
                        </div>
                        <div>
                            <StatusBadge status={app.status} />
                        </div>
                    </div>
                ))}
                {apps.length === 0 && (
                    <div className="text-center py-20 text-gray-500 bg-white/5 rounded-3xl border border-dashed border-gray-700">
                        You haven't applied to any jobs yet.
                    </div>
                )}
            </div>
        </div>
    );
};

const StatusBadge = ({ status }) => {
    const styles = {
        'SELECTED': 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30',
        'REJECTED': 'bg-red-500/20 text-red-300 border-red-500/30',
        'SHORTLISTED': 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30',
        'APPLIED': 'bg-blue-500/20 text-blue-300 border-blue-500/30'
    };
    return (
        <span className={`px-4 py-2 rounded-xl text-sm font-bold border ${styles[status]}`}>
            {status}
        </span>
    );
};

export default CandidateDashboard;
