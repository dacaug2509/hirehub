import { useEffect, useState } from 'react';
import { Routes, Route, Link, useNavigate, useLocation } from 'react-router-dom';
import api from '../api/axios';

const CompanyDashboard = () => {
    const location = useLocation();

    return (
        <div className="dashboard-container">
            {/* Sidebar */}
            <aside className="sidebar">
                <div className="p-6 flex items-center gap-3 border-b border-gray-800">
                    <div className="w-8 h-8 bg-purple-600 rounded-lg flex items-center justify-center font-bold text-white">CP</div>
                    <div className="font-bold text-lg">Company<span className="text-purple-400">Portal</span></div>
                </div>
                <nav className="p-4 space-y-2">
                    <NavItem to="/company" label="Overview" icon="chart-bar" active={location.pathname === '/company'} />
                    <NavItem to="/company/post-job" label="Post New Job" icon="plus" active={location.pathname === '/company/post-job'} />
                    <NavItem to="/company/employees" label="Employees" icon="users" active={location.pathname === '/company/employees'} />
                </nav>
            </aside>

            {/* Content */}
            <main className="main-content">
                <div className="max-w-6xl mx-auto">
                    <Routes>
                        <Route path="/" element={<JobsList />} />
                        <Route path="/post-job" element={<PostJob />} />
                        <Route path="/employees" element={<EmployeesList />} />
                        <Route path="/job/:id/applicants" element={<JobApplicants />} />
                    </Routes>
                </div>
            </main>
        </div>
    );
};

const NavItem = ({ to, label, icon, active }) => (
    <Link to={to} className={`flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${active ? 'bg-purple-600 text-white shadow-lg shadow-purple-900/40' : 'text-gray-400 hover:text-white hover:bg-gray-800'}`}>
        <span>{label}</span>
        {active && <span className="ml-auto text-xs opacity-75">●</span>}
    </Link>
);

const JobsList = () => {
    const [jobs, setJobs] = useState([]);
    const navigate = useNavigate();

    useEffect(() => {
        api.get('/company/jobs').then(res => setJobs(res.data));
    }, []);

    const deleteJob = async (id) => {
        if (confirm('Are you sure?')) {
            await api.delete(`/company/jobs/${id}`);
            setJobs(jobs.filter(j => j.id !== id));
        }
    };

    return (
        <div className="animate-fade-in">
            <div className="flex justify-between items-center mb-8">
                <div>
                    <h2 className="text-2xl font-bold text-gray-800">Job Listings</h2>
                    <p className="text-gray-500 text-sm">Manage your active recruitment campaigns</p>
                </div>
                <button onClick={() => navigate('/company/post-job')} className="btn-accent">+ Post Job</button>
            </div>

            <div className="grid gap-4">
                {jobs.map(job => (
                    <div key={job.id} className="card-white flex justify-between items-center group hover:border-blue-500/30">
                        <div>
                            <div className="flex items-center gap-3 mb-1">
                                <h3 className="font-bold text-lg text-gray-800">{job.title}</h3>
                                <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full ${job.status === 'OPEN' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                                    {job.status}
                                </span>
                            </div>
                            <p className="text-gray-500 text-sm line-clamp-1 max-w-xl">{job.description}</p>
                            <div className="mt-3 flex gap-2">
                                {job.requiredSkills.split(',').map(s => <span key={s} className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded">{s}</span>)}
                            </div>
                        </div>
                        <div className="flex items-center gap-3 opacity-80 group-hover:opacity-100 transition-opacity">
                            <button onClick={() => navigate(`/company/job/${job.id}/applicants`)} className="px-4 py-2 bg-blue-50 text-blue-600 rounded-lg text-sm font-bold hover:bg-blue-100">Applicants</button>
                            <button onClick={() => deleteJob(job.id)} className="px-4 py-2 bg-red-50 text-red-600 rounded-lg text-sm font-bold hover:bg-red-100">Delete</button>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

const PostJob = () => {
    const [formData, setFormData] = useState({ title: '', description: '', requiredSkills: '' });
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        await api.post('/company/jobs', formData);
        navigate('/company');
    };

    return (
        <div className="card-white max-w-2xl mx-auto">
            <h2 className="text-xl font-bold text-gray-800 mb-6 pb-4 border-b border-gray-100">Create New Position</h2>
            <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                    <label className="block text-xs font-bold text-gray-500 uppercase tracking-wide mb-2">Job Title</label>
                    <input className="input-field bg-gray-50 border-gray-200 focus:bg-white" placeholder="e.g. Senior Product Designer" onChange={e => setFormData({ ...formData, title: e.target.value })} required />
                </div>
                <div>
                    <label className="block text-xs font-bold text-gray-500 uppercase tracking-wide mb-2">Description</label>
                    <textarea className="input-field bg-gray-50 border-gray-200 focus:bg-white h-32" placeholder="Job details..." onChange={e => setFormData({ ...formData, description: e.target.value })} required />
                </div>
                <div>
                    <label className="block text-xs font-bold text-gray-500 uppercase tracking-wide mb-2">Required Skills</label>
                    <input className="input-field bg-gray-50 border-gray-200 focus:bg-white" placeholder="React, Node.js (Comma separated)" onChange={e => setFormData({ ...formData, requiredSkills: e.target.value })} required />
                </div>
                <div className="pt-4 flex gap-4">
                    <button type="button" onClick={() => navigate('/company')} className="px-6 py-2.5 rounded-lg font-bold text-gray-500 hover:bg-gray-100">Cancel</button>
                    <button type="submit" className="btn-accent px-8">Publish Job</button>
                </div>
            </form>
        </div>
    );
};

const EmployeesList = () => {
    const [employees, setEmployees] = useState([]);
    useEffect(() => {
        api.get('/company/employees').then(res => setEmployees(res.data));
    }, []);
    return (
        <div className="grid grid-cols-3 gap-6">
            {employees.map(e => (
                <div key={e.id} className="card-white flex items-center gap-4">
                    <div className="w-10 h-10 rounded-full bg-purple-100 text-purple-600 flex items-center justify-center font-bold">{e.name.charAt(0)}</div>
                    <div>
                        <div className="font-bold text-gray-800">{e.name}</div>
                        <div className="text-xs text-gray-400">Employee ID: #{e.id}</div>
                    </div>
                </div>
            ))}
        </div>
    );
};

const JobApplicants = () => <div className="text-center py-12 text-gray-400">Select a job to view applicants</div>;

export default CompanyDashboard;
