import { Routes, Route, Navigate } from 'react-router-dom';
import Login from './pages/Login';
import Register from './pages/Register';
import AdminDashboard from './pages/AdminDashboard';
import CompanyDashboard from './pages/CompanyDashboard';
import CandidateDashboard from './pages/CandidateDashboard';
import EmployeeDashboard from './pages/EmployeeDashboard';
import PrivateRoute from './components/PrivateRoute';
import { AuthProvider } from './context/AuthContext';

function App() {
  return (
    <AuthProvider>
      <div className="min-h-screen text-gray-100">
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/" element={<Navigate to="/login" />} />
          <Route path="/unauthorized" element={<div className='p-10 text-center text-3xl font-bold'>Unauthorized Access</div>} />

          {/* Protected Routes */}
          <Route element={<PrivateRoute roles={['ADMIN']} />}>
            <Route path="/admin" element={<AdminDashboard />} />
          </Route>

          <Route element={<PrivateRoute roles={['COMPANY']} />}>
            <Route path="/company/*" element={<CompanyDashboard />} />
          </Route>

          <Route element={<PrivateRoute roles={['CANDIDATE']} />}>
            <Route path="/candidate/*" element={<CandidateDashboard />} />
          </Route>

          <Route element={<PrivateRoute roles={['EMPLOYEE']} />}>
            <Route path="/employee/*" element={<EmployeeDashboard />} />
          </Route>

        </Routes>
      </div>
    </AuthProvider>
  );
}

export default App;
