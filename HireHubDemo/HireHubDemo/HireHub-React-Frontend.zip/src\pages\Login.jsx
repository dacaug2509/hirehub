import { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useNavigate, Link } from 'react-router-dom';

const Login = () => {
    // Roles: 'ADMIN', 'COMPANY', 'CANDIDATE', 'EMPLOYEE'
    const [activeTab, setActiveTab] = useState('CANDIDATE');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const { login } = useAuth();
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');
        try {
            // Employee is specialized, others are standard users in Spring Boot
            const isEmployeeIdx = activeTab === 'EMPLOYEE';
            await login(email, password, isEmployeeIdx);

            // Redirect based on the tab selected (verifies they logged in as the right role)
            const role = localStorage.getItem('role'); // e.g., 'ADMIN'

            if (activeTab !== 'EMPLOYEE' && role !== activeTab) {
                // If they tried to login as Admin but account is Candidate, warn them? 
                // Or just let them through. Let's just redirect to their actual Dashboard.
            }

            if (role === 'ADMIN') navigate('/admin');
            else if (role === 'COMPANY') navigate('/company');
            else if (role === 'CANDIDATE') navigate('/candidate');
            else if (role === 'EMPLOYEE') navigate('/employee');
        } catch (err) {
            setError('Invalid Credentials');
        }
    };

    const tabs = [
        { id: 'CANDIDATE', label: 'Candidate' },
        { id: 'COMPANY', label: 'Company' },
        { id: 'ADMIN', label: 'Admin' },
        { id: 'EMPLOYEE', label: 'Employee' }
    ];

    return (
        <div className="auth-bg flex items-center justify-center min-h-screen p-4">
            <div className="bg-white/90 backdrop-blur-xl p-8 rounded-2xl w-full max-w-md shadow-2xl border border-white/50 relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-blue-400 to-purple-500"></div>

                <h1 className="text-2xl font-light text-center tracking-wide text-gray-800 mb-6 uppercase">
                    HireHub Login
                </h1>

                {/* 4-Tab Navigation */}
                <div className="flex justify-between border-b border-gray-200 mb-8 overflow-x-auto gap-2 pb-1">
                    {tabs.map(tab => (
                        <button
                            key={tab.id}
                            onClick={() => setActiveTab(tab.id)}
                            className={`text-[10px] font-bold uppercase tracking-wider px-2 py-2 transition-all whitespace-nowrap ${activeTab === tab.id
                                    ? 'text-blue-600 border-b-2 border-blue-600'
                                    : 'text-gray-400 hover:text-gray-600'
                                }`}
                        >
                            {tab.label}
                        </button>
                    ))}
                </div>

                <div className="text-center mb-6">
                    <span className="text-xs font-bold text-gray-400 uppercase tracking-widest">
                        Logging in as <span className="text-blue-600">{tabs.find(t => t.id === activeTab).label}</span>
                    </span>
                </div>

                {error && <div className="text-red-500 text-xs text-center mb-4 font-bold bg-red-50 py-2 rounded">{error}</div>}

                <form onSubmit={handleSubmit} className="space-y-5">
                    <div className="relative group">
                        <span className="absolute left-0 top-3 text-gray-400 group-focus-within:text-blue-500 transition-colors">✉️</span>
                        <input
                            type="email"
                            className="w-full bg-transparent border-b-2 border-gray-200 py-3 pl-8 text-sm focus:outline-none focus:border-blue-500 transition-colors text-gray-700 placeholder-gray-400"
                            placeholder={`${tabs.find(t => t.id === activeTab).label} Email`}
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                        />
                    </div>
                    <div className="relative group">
                        <span className="absolute left-0 top-3 text-gray-400 group-focus-within:text-blue-500 transition-colors">🔒</span>
                        <input
                            type="password"
                            className="w-full bg-transparent border-b-2 border-gray-200 py-3 pl-8 text-sm focus:outline-none focus:border-blue-500 transition-colors text-gray-700 placeholder-gray-400"
                            placeholder="Password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                        />
                    </div>

                    <button type="submit" className="w-full bg-[#0f172a] text-white font-bold py-3 text-xs tracking-[2px] uppercase hover:bg-blue-900 transition-all shadow-lg hover:shadow-xl rounded mt-4">
                        Login as {tabs.find(t => t.id === activeTab).label}
                    </button>
                </form>

                <div className="mt-8 text-center border-t border-gray-100 pt-6">
                    <p className="text-gray-400 text-xs">New to HireHub?</p>
                    <Link to="/register" className="text-blue-600 text-xs font-bold uppercase tracking-wide hover:underline mt-2 inline-block">Create an Account</Link>
                </div>
            </div>
        </div>
    );
};

export default Login;
