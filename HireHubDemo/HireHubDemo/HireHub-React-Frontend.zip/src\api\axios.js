import axios from 'axios';

const api = axios.create({
    baseURL: 'http://localhost:8080/api', // Default to Core Service
});

// Interceptor to add Token
api.interceptors.request.use((config) => {
    const token = localStorage.getItem('token');
    if (token) {
        config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
});

export const referralApi = axios.create({
    baseURL: 'http://localhost:5000/api', // .NET Service
});

referralApi.interceptors.request.use((config) => {
    const token = localStorage.getItem('token');
    if (token) {
        config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
});

export default api;
