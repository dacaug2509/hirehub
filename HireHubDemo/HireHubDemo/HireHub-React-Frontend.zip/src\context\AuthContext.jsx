import { createContext, useState, useEffect, useContext } from 'react';
import api from '../api/axios';
import axios from 'axios';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        // Decode token or check local storage
        const token = localStorage.getItem('token');
        const role = localStorage.getItem('role');
        const userId = localStorage.getItem('userId');
        if (token && role) {
            setUser({ token, role, userId });
        }
        setLoading(false);
    }, []);

    const login = async (email, password, isEmployee = false) => {
        try {
            if (isEmployee) {
                // Employee Login via .NET
                const response = await axios.post('http://localhost:5000/api/auth/login', { email, password });
                const { token, role, userId } = response.data; // Note: .NET returns CamelCase keys usually, need to check Program.cs JSON options. Default is camelCase.
                localStorage.setItem('token', token);
                localStorage.setItem('role', role); // Expected "EMPLOYEE"
                localStorage.setItem('userId', userId);
                setUser({ token, role, userId });
                return true;
            } else {
                // Core Login
                const response = await api.post('http://localhost:8080/auth/login', { email, password });
                const { token, role, userId } = response.data;
                localStorage.setItem('token', token);
                localStorage.setItem('role', role);
                localStorage.setItem('userId', userId);
                setUser({ token, role, userId });
                return true;
            }
        } catch (error) {
            console.error("Login failed", error);
            throw error;
        }
    };

    const register = async (data) => {
        // Only Core Registration for now
        await api.post('http://localhost:8080/auth/register', data);
    };

    const logout = () => {
        localStorage.removeItem('token');
        localStorage.removeItem('role');
        localStorage.removeItem('userId');
        setUser(null);
    };

    return (
        <AuthContext.Provider value={{ user, login, register, logout, loading }}>
            {children}
        </AuthContext.Provider>
    );
};

export const useAuth = () => useContext(AuthContext);
