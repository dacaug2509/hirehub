import { useEffect, useState } from 'react';
import { referralApi } from '../api/axios';

const EmployeeDashboard = () => {
    const [jobs, setJobs] = useState([]);
    const [candidates, setCandidates] = useState([]);
    const [searchName, setSearchName] = useState('');
    const [selectedJob, setSelectedJob] = useState(null);

    useEffect(() => {
        referralApi.get('/referral/jobs').then(res => setJobs(res.data));
    }, []);

    const searchCandidates = async () => {
        const res = await referralApi.get(`/referral/candidates?name=${searchName}`);
        setCandidates(res.data);
    };

    const refer = async (candidateId) => {
        if (!selectedJob) return alert('Please select a job position first');
        try {
            await referralApi.post(`/referral/refer?jobId=${selectedJob}&candidateId=${candidateId}`);
            alert('Candidate Referred Successfully! 🎉');
        } catch (err) {
            alert(err.response?.data || 'Failed to refer');
        }
    };

    return (
        <div className="p-10 container mx-auto">
            <header className="mb-12 text-center animate-fade-in">
                <h1 className="text-6xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-teal-400 to-cyan-400 mb-4">Referral Hub</h1>
                <p className="text-xl text-gray-400 max-w-2xl mx-auto">Connect great talent with open positions and earn rewards.</p>
            </header>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
                {/* Job Selection */}
                <div className="glass p-8 rounded-3xl animate-fade-in delay-100 flex flex-col h-[600px]">
                    <h2 className="text-2xl font-bold mb-6 text-emerald-400 flex items-center gap-3">
                        <span className="w-8 h-8 rounded-lg bg-emerald-500/20 flex items-center justify-center text-sm">1</span>
                        Select Open Position
                    </h2>
                    <div className="space-y-4 overflow-y-auto pr-2 flex-1 custom-scrollbar">
                        {jobs.map(job => (
                            <div
                                key={job.id}
                                onClick={() => setSelectedJob(job.id)}
                                className={`p-6 rounded-2xl cursor-pointer border transition-all duration-300 relative group overflow-hidden ${selectedJob === job.id ? 'bg-emerald-900/40 border-emerald-500 shadow-lg shadow-emerald-500/10' : 'bg-white/5 border-transparent hover:bg-white/10'}`}
                            >
                                <div className={`absolute left-0 top-0 bottom-0 w-1 transition-all ${selectedJob === job.id ? 'bg-emerald-500' : 'bg-transparent'}`}></div>
                                <h3 className="font-bold text-lg mb-1">{job.title}</h3>
                                <p className="text-sm text-gray-400 line-clamp-2">{job.description}</p>
                            </div>
                        ))}
                    </div>
                </div>

                {/* Candidate Search */}
                <div className="glass p-8 rounded-3xl animate-fade-in delay-200 flex flex-col h-[600px]">
                    <h2 className="text-2xl font-bold mb-6 text-cyan-400 flex items-center gap-3">
                        <span className="w-8 h-8 rounded-lg bg-cyan-500/20 flex items-center justify-center text-sm">2</span>
                        Find Talent
                    </h2>

                    <div className="flex gap-3 mb-8">
                        <input
                            className="input-field py-4 bg-black/30"
                            placeholder="Search Candidate Name..."
                            value={searchName}
                            onChange={(e) => setSearchName(e.target.value)}
                        />
                        <button onClick={searchCandidates} className="btn-primary py-3 px-8 bg-gradient-to-r from-cyan-500 to-blue-500">Search</button>
                    </div>

                    <div className="space-y-4 flex-1 overflow-y-auto pr-2 custom-scrollbar">
                        {candidates.map(c => (
                            <div key={c.id} className="bg-black/30 p-5 rounded-2xl flex justify-between items-center group hover:bg-black/40 transition-colors border border-white/5">
                                <div className="flex items-center gap-4">
                                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-gray-700 to-gray-900 flex items-center justify-center font-bold text-gray-400">
                                        {c.name.charAt(0)}
                                    </div>
                                    <div>
                                        <div className="font-bold text-lg">{c.name}</div>
                                        <div className="text-xs text-gray-500 uppercase tracking-wide">{c.skills}</div>
                                    </div>
                                </div>
                                <button
                                    onClick={() => refer(c.id)}
                                    className={`px-6 py-2 rounded-xl text-sm font-bold transition-all shadow-lg ${selectedJob ? 'bg-emerald-500 hover:bg-emerald-400 text-black shadow-emerald-500/20 transform hover:-translate-y-1' : 'bg-gray-800 text-gray-600 cursor-not-allowed'}`}
                                    disabled={!selectedJob}
                                >
                                    Refer Now
                                </button>
                            </div>
                        ))}
                        {candidates.length === 0 && (
                            <div className="h-full flex flex-col items-center justify-center text-gray-500 pb-10">
                                <span className="text-4xl mb-4 opacity-50">👥</span>
                                <p>Search for a candidate to start referring</p>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default EmployeeDashboard;
