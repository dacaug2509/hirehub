import { useEffect, useState } from 'react';
import api from '../api/axios';

const AdminDashboard = () => {
    const [pendingCompanies, setPendingCompanies] = useState([]);
    const [users, setUsers] = useState([]);
    const [selectedRole, setSelectedRole] = useState('COMPANY');

    useEffect(() => { fetchPendingCompanies(); }, []);

    const fetchPendingCompanies = async () => {
        try { setPendingCompanies((await api.get('/admin/companies/pending')).data); } catch (err) { }
    };

    const fetchUsers = async (role) => {
        try {
            setUsers((await api.get(`/admin/users?role=${role}`)).data);
            setSelectedRole(role);
        } catch (err) { }
    };

    const approveCompany = async (id) => {
        await api.put(`/admin/company/${id}/approve`);
        fetchPendingCompanies();
    };

    const deleteCompany = async (id) => {
        await api.delete(`/admin/company/${id}`);
        fetchPendingCompanies();
    };

    return (
        <div className="dashboard-container font-sans text-gray-800">
            {/* Sidebar */}
            <aside className="sidebar">
                <div className="p-6 border-b border-gray-800 flex items-center gap-3">
                    <div className="w-8 h-8 bg-blue-500 rounded-lg flex items-center justify-center font-bold text-white">HH</div>
                    <h1 className="text-xl font-bold tracking-tight">HireHub<span className="text-blue-500">.Admin</span></h1>
                </div>
                <nav className="p-4 space-y-1">
                    <div className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-2 px-3">Main</div>
                    <a href="#" className="flex items-center gap-3 px-3 py-2 bg-blue-600 rounded-md text-white shadow-lg shadow-blue-900/50">
                        <span>📊</span> Dashboard
                    </a>
                    <a href="#" className="flex items-center gap-3 px-3 py-2 text-gray-400 hover:text-white hover:bg-gray-800 rounded-md transition-colors">
                        <span>👥</span> Users
                    </a>
                    <a href="#" className="flex items-center gap-3 px-3 py-2 text-gray-400 hover:text-white hover:bg-gray-800 rounded-md transition-colors">
                        <span>🏢</span> Companies
                    </a>
                </nav>
            </aside>

            {/* Content */}
            <main className="main-content">
                {/* Stats Row */}
                <div className="grid grid-cols-4 gap-6 mb-8">
                    <div className="card-white p-6 border-l-4 border-blue-500">
                        <div className="text-gray-400 text-xs font-bold uppercase tracking-wider">Total Users</div>
                        <div className="text-3xl font-bold text-gray-800 mt-1">1,245</div>
                        <div className="text-green-500 text-xs font-bold mt-2">▲ 13% vs last week</div>
                    </div>
                    <div className="card-white p-6 border-l-4 border-purple-500">
                        <div className="text-gray-400 text-xs font-bold uppercase tracking-wider">Companies</div>
                        <div className="text-3xl font-bold text-gray-800 mt-1">84</div>
                        <div className="text-green-500 text-xs font-bold mt-2">▲ 4 New this week</div>
                    </div>
                    <div className="card-white p-6 border-l-4 border-orange-500">
                        <div className="text-gray-400 text-xs font-bold uppercase tracking-wider">Jobs Posted</div>
                        <div className="text-3xl font-bold text-gray-800 mt-1">452</div>
                        <div className="text-gray-400 text-xs font-bold mt-2">-- Stable</div>
                    </div>
                    <div className="card-white p-6 border-l-4 border-emerald-500">
                        <div className="text-gray-400 text-xs font-bold uppercase tracking-wider">Applications</div>
                        <div className="text-3xl font-bold text-gray-800 mt-1">8,992</div>
                        <div className="text-green-500 text-xs font-bold mt-2">▲ 24% Spike</div>
                    </div>
                </div>

                <div className="grid grid-cols-3 gap-8">
                    {/* Pending Approvals Table (Col Span 2) */}
                    <div className="col-span-2 card-white">
                        <div className="flex justify-between items-center mb-6">
                            <h2 className="text-lg font-bold text-gray-800">Pending Company Approvals</h2>
                            <button className="text-xs text-blue-600 font-bold hover:underline">View All</button>
                        </div>

                        <div className="overflow-x-auto">
                            <table className="w-full text-left">
                                <thead>
                                    <tr className="border-b border-gray-100 text-gray-400 text-xs uppercase tracking-wider">
                                        <th className="pb-3 pl-2">Company</th>
                                        <th className="pb-3">Contact</th>
                                        <th className="pb-3 text-right">Actions</th>
                                    </tr>
                                </thead>
                                <tbody className="text-sm">
                                    {pendingCompanies.length === 0 ? (
                                        <tr><td colSpan="3" className="py-8 text-center text-gray-400 italic">No pending requests</td></tr>
                                    ) : (
                                        pendingCompanies.map(c => (
                                            <tr key={c.id} className="border-b border-gray-50 last:border-0 hover:bg-gray-50/50">
                                                <td className="py-3 pl-2 font-medium text-gray-800">{c.name}</td>
                                                <td className="py-3 text-gray-500">{c.user?.email}</td>
                                                <td className="py-3 text-right space-x-2">
                                                    <button onClick={() => approveCompany(c.id)} className="text-xs bg-emerald-100 text-emerald-700 font-bold px-3 py-1 rounded hover:bg-emerald-200">Approve</button>
                                                    <button onClick={() => deleteCompany(c.id)} className="text-xs bg-red-100 text-red-700 font-bold px-3 py-1 rounded hover:bg-red-200">Reject</button>
                                                </td>
                                            </tr>
                                        ))
                                    )}
                                </tbody>
                            </table>
                        </div>
                    </div>

                    {/* User Filter (Col Span 1) */}
                    <div className="card-white">
                        <h2 className="text-lg font-bold text-gray-800 mb-4">User Directory</h2>
                        <div className="flex gap-2 mb-4">
                            <button onClick={() => fetchUsers('CANDIDATE')} className={`flex-1 py-1 text-xs font-bold rounded ${selectedRole === 'CANDIDATE' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-500'}`}>Candidates</button>
                            <button onClick={() => fetchUsers('COMPANY')} className={`flex-1 py-1 text-xs font-bold rounded ${selectedRole === 'COMPANY' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-500'}`}>Companies</button>
                        </div>
                        <div className="space-y-3 max-h-[300px] overflow-y-auto">
                            {users.map(u => (
                                <div key={u.id} className="flex items-center gap-3 p-3 rounded-lg border border-gray-100 hover:shadow-md transition-all bg-gray-50/30">
                                    <div className={`w-2 h-2 rounded-full ${u.isActive ? 'bg-emerald-500' : 'bg-red-500'}`}></div>
                                    <div className="overflow-hidden">
                                        <div className="text-sm font-bold text-gray-700 truncate w-40" title={u.email}>{u.email}</div>
                                        <div className="text-xs text-gray-400">ID: {u.id}</div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </main>
        </div>
    );
};

export default AdminDashboard;
