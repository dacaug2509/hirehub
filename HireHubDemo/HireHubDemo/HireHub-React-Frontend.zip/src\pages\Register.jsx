import { useState } from 'react';
import api from '../api/axios';
import { referralApi } from '../api/axios'; // Assuming separate API for .NET
import { useNavigate, Link } from 'react-router-dom';

const Register = () => {
    // Tabs: 'CANDIDATE', 'COMPANY', 'EMPLOYEE'
    const [activeTab, setActiveTab] = useState('CANDIDATE');
    const [formData, setFormData] = useState({
        name: '', email: '', password: '',
        skills: '', experience: '', profileUrl: '', // Candidate specific
        description: '', // Company specific
        department: 'Engineering' // Employee specific logic if needed
    });
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            if (activeTab === 'CANDIDATE') {
                await api.post('/auth/register/candidate', formData);
            } else if (activeTab === 'COMPANY') {
                await api.post('/auth/register/company', formData);
            } else if (activeTab === 'EMPLOYEE') {
                // Assuming .NET endpoint, or we map to a core user for now
                // Since the backend logic for Employee registration might be complex,
                // we'll try to hit the referral service Or the generic auth if configured.
                // For this demo, let's assume we post to the Referral API directly
                await referralApi.post('/auth/register', { ...formData, role: 'EMPLOYEE' });
            }
            alert('Registration Successful! Please Login.');
            navigate('/login');
        } catch (err) {
            console.error(err);
            alert('Registration Failed. ' + (err.response?.data || ''));
        }
    };

    return (
        <div className="auth-bg flex items-center justify-center min-h-screen p-4">
            <div className="bg-white/90 backdrop-blur-xl p-8 rounded-2xl w-full max-w-lg shadow-2xl border border-white/50 relative">
                <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-blue-400 to-purple-500"></div>

                <h1 className="text-2xl font-light text-center tracking-wide text-gray-800 mb-6 uppercase">
                    Join HireHub
                </h1>

                {/* 3-Tab Navigation */}
                <div className="flex justify-center border-b border-gray-200 mb-8 gap-4">
                    {['CANDIDATE', 'COMPANY', 'EMPLOYEE'].map(tab => (
                        <button
                            key={tab}
                            onClick={() => setActiveTab(tab)}
                            className={`pb-2 text-xs font-bold uppercase tracking-wider transition-all ${activeTab === tab
                                    ? 'text-blue-600 border-b-2 border-blue-600'
                                    : 'text-gray-400 hover:text-gray-600'
                                }`}
                        >
                            {tab}
                        </button>
                    ))}
                </div>

                <form onSubmit={handleSubmit} className="space-y-4">
                    <input className="input-clean" placeholder="Full Name" onChange={e => setFormData({ ...formData, name: e.target.value })} required />
                    <input className="input-clean" type="email" placeholder="Email Address" onChange={e => setFormData({ ...formData, email: e.target.value })} required />
                    <input className="input-clean" type="password" placeholder="Password" onChange={e => setFormData({ ...formData, password: e.target.value })} required />

                    {activeTab === 'CANDIDATE' && (
                        <>
                            <input className="input-clean" placeholder="Skills (e.g. Java, React)" onChange={e => setFormData({ ...formData, skills: e.target.value })} required />
                            <input className="input-clean" placeholder="Years of Experience" type="number" onChange={e => setFormData({ ...formData, experience: e.target.value })} required />
                        </>
                    )}

                    {activeTab === 'COMPANY' && (
                        <textarea className="input-clean h-24 resize-none" placeholder="Company Description & Vision" onChange={e => setFormData({ ...formData, description: e.target.value })} required />
                    )}

                    {activeTab === 'EMPLOYEE' && (
                        <div className="p-4 bg-blue-50 text-blue-800 text-xs rounded border border-blue-100">
                            <strong>Note:</strong> You will be registered in the Employee Referral System.
                        </div>
                    )}

                    <button type="submit" className="w-full bg-[#0f172a] text-white font-bold py-3 text-xs tracking-[2px] uppercase hover:bg-blue-900 transition-all shadow-lg rounded mt-6">
                        Register as {activeTab}
                    </button>
                </form>

                <div className="mt-8 text-center border-t border-gray-100 pt-6">
                    <p className="text-gray-400 text-xs">Already have an account?</p>
                    <Link to="/login" className="text-blue-600 text-xs font-bold uppercase tracking-wide hover:underline mt-2 inline-block">Login Here</Link>
                </div>
            </div>
        </div>
    );
};

export default Register;
